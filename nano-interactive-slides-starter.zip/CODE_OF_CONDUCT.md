# Code of Conduct

We are committed to a harassment‑free, collaborative environment.
- Be respectful and inclusive.
- Assume good intent; critique ideas, not people.
- No discrimination or harassment.
Violations may result in temporary or permanent exclusion.
