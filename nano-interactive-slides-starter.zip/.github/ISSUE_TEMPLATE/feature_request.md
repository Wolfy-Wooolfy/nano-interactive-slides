---
name: Feature request
about: Suggest an idea
title: "[Feature] "
labels: enhancement
assignees: ""
---

**Problem**

**Proposed solution**

**Alternatives**

**Additional context**
