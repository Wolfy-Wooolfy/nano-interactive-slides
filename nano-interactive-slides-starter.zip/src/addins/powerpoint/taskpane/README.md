# PowerPoint Add-in (Task Pane)

Dev commands (example):
```bash
pnpm install
pnpm dev
```
Sideload `manifest.xml` in PowerPoint (Developer > Add-ins > Sideload).