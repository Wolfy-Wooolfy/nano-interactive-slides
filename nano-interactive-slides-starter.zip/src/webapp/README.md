# Webapp (Shared UI)

React + Vite placeholder for shared components (knobs, charts, overlays).
