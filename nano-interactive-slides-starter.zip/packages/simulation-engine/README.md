# Simulation Engine

Headless state/update/render loop.
- Entities: Node, Edge, Queue
- Ticks with dt
- Outputs: metrics for charts
